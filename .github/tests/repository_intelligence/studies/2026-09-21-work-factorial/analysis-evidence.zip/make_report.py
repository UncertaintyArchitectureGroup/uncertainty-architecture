"""Join already-frozen first scores and apply the unchanged benefit gates."""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent / 'ua-repo/.github/tests/repository_intelligence/studies/2026-09-21-work-factorial'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


freeze = json.loads((ROOT / 'assessment-first-freeze.json').read_text())
raw = (ROOT / 'scores-first.json').read_bytes()
assert sha(raw) == freeze['assessment_sha256']
mapping_raw = (ROOT / 'assessment-mapping.json').read_bytes()
assert sha(mapping_raw) == freeze['assessment_input_freeze']['mapping_sha256']
mapping = {r['answer_id']: r for r in json.loads(mapping_raw)}
scores = json.loads(raw)
ledger = json.loads((ROOT / 'runs.json').read_text())['runs']
by_run = {r['run_id']: r for r in ledger}
for answer in scores['assessments']:
    match = mapping[answer['answer_id']]
    row = by_run[match['run_id']]
    assert match['sha256'] == row['first_answer_sha256']
    row.update(answer_id=answer['answer_id'], score=answer['score'],
               criteria_met=sum(c['verdict'] == 'met' for c in answer['criteria']),
               serious_error_count=sum(e['present'] for e in answer['serious_errors']),
               required_corrections=answer['required_corrections'])
arms = ['NONE', 'AGENTS', 'RI', 'AGENTS_RI']
metrics = ['driver_operations', 'start_delivery_operations', 'source_ri_operations', 'measured_input_utf8_bytes']
totals = {arm: {key: sum(r[key] for r in ledger if r['arm'] == arm) for key in metrics} for arm in arms}
cells = {(r['task_id'], r['arm']): r for r in ledger}
comparisons = []
for control, treatment in [('AGENTS', 'AGENTS_RI'), ('NONE', 'RI'), ('NONE', 'AGENTS'), ('RI', 'AGENTS_RI')]:
    pairs = [(cells[task, control], cells[task, treatment]) for task in ['F1', 'F2', 'F3']]
    comparisons.append({'control': control, 'treatment': treatment,
                        'wins': sum(t['score'] > c['score'] for c, t in pairs),
                        'losses': sum(t['score'] < c['score'] for c, t in pairs),
                        'ties': sum(t['score'] == c['score'] for c, t in pairs),
                        'operations_ratio': totals[treatment]['source_ri_operations'] / totals[control]['source_ri_operations'],
                        'input_bytes_ratio': totals[treatment]['measured_input_utf8_bytes'] / totals[control]['measured_input_utf8_bytes']})
primary = comparisons[0]
pairs = [(cells[t, 'AGENTS'], cells[t, 'AGENTS_RI']) for t in ['F1', 'F2', 'F3']]
all_valid = all(r['status'] == 'answer_received' and not r['reader_boundary_findings'] and all(r['read_coverage'].values()) for c, t in pairs for r in [c, t])
quality_improvements = sum(t['score'] == 2 and t['score'] > c['score'] for c, t in pairs)
no_loss = primary['losses'] == 0 and all(t['serious_error_count'] <= c['serious_error_count'] for c, t in pairs)
all_full = all(r['score'] == 2 for c, t in pairs for r in [c, t])
quality_gate = all_valid and no_loss and quality_improvements >= 2
efficiency_gate = all_valid and no_loss and all_full and primary['operations_ratio'] <= 0.80 and primary['input_bytes_ratio'] <= 1
analysis = {'joined_observed_at': datetime.now(timezone.utc).isoformat(),
            'first_score_freeze_commit': 'c86409d9377b4737f7d980a12c2fe260527f1dc3',
            'assessment_sha256': sha(raw), 'runs': ledger, 'totals': totals,
            'comparisons': comparisons,
            'primary_gate': {'all_pairs_valid_within_instructional_protocol': all_valid,
                             'no_quality_loss_or_new_serious_error': no_loss,
                             'improvements_reaching_2': quality_improvements,
                             'quality_signal': quality_gate, 'all_six_primary_scores_2': all_full,
                             'operations_ratio': primary['operations_ratio'],
                             'operations_threshold': 0.80, 'input_bytes_ratio': primary['input_bytes_ratio'],
                             'input_bytes_threshold': 1.0, 'efficiency_signal': efficiency_gate},
            'claim_limit': 'No significance, equivalence, general RI ineffectiveness, cognition or full RI-EVAL acceptance claim.'}
(ROOT / 'analysis.json').write_text(json.dumps(analysis, ensure_ascii=False, indent=2) + '\n')
(STUDY / 'analysis.json').write_bytes((ROOT / 'analysis.json').read_bytes())
(STUDY / 'assessment-mapping.json').write_bytes(mapping_raw)
lines = ['# First assessment and frozen criteria', '',
         'The first assessment was preserved in `assessment-first.zip` and published at',
         '`c86409d9377b4737f7d980a12c2fe260527f1dc3` before joining conditions.',
         'SHA-256: `'+sha(raw)+'`. No scores were revised.', '',
         'C1–C5 are the unchanged five criteria for each task in the assessment packet.',
         'The archive contains the assessor’s verbatim quotations, owning-source',
         'evidence, serious-error judgments, rationales and uncertainty notes.', '',
         '| Run | Task | Arm | Opaque ID | C1 | C2 | C3 | C4 | C5 | Score |',
         '|---|---|---|---|---|---|---|---|---|---|']
for row in ledger:
    a = next(a for a in scores['assessments'] if a['answer_id'] == row['answer_id'])
    verdicts = ' | '.join(c['verdict'] for c in sorted(a['criteria'], key=lambda c: c['criterion_index']))
    lines.append(f"| {row['run_id']} | {row['task_id']} | {row['arm']} | {row['answer_id']} | {verdicts} | {row['score']} |")
lines += ['', 'All 60 criterion judgments are met; all 36 frozen serious-error judgments',
          'are absent. There are no required substantive corrections. These counts are',
          'assessor decisions, not independent observations or a percentage of understanding.', '',
          'The assessor treats WF07’s research-traceability sentence as conditional on',
          'actual material findings, consistent with the cited process. Making the condition',
          'more explicit is an optional clarity improvement, not a frozen-criterion failure.', '',
          'The WF10 and WF12 access statements reveal absent aids. The assessor reported',
          'that wording and excluded it from substantive scoring. Full blinding cannot',
          'therefore be claimed. This is one fresh agent assessor, not human replication.', '']
assert all(r['score'] == 2 and r['criteria_met'] == 5 and r['serious_error_count'] == 0 and not r['required_corrections'] for r in ledger), 'Narrative needs source-grounded adaptation, never score changes'
(STUDY / 'SCORES.md').write_text('\n'.join(lines))
with zipfile.ZipFile(STUDY / 'analysis-evidence.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    for name in ['analysis.json', 'assessment-mapping.json', 'assessment-first-freeze.json', 'audit.json', 'runs.json', 'audit_results.py', 'make_report.py']:
        z.write(ROOT / name, name)
print(json.dumps({'totals': totals, 'comparisons': comparisons, 'primary_gate': analysis['primary_gate']}, ensure_ascii=False, indent=2))
