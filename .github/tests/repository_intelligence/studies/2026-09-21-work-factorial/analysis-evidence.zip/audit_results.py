"""Verify retained bytes and the observable reader record without assigning quality."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'ua-repo'
STUDY = REPO / '.github/tests/repository_intelligence/studies/2026-09-21-work-factorial'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def allowed(rel, guide, ri):
    p = Path(rel)
    assert not p.is_absolute() and '..' not in p.parts
    return not ((p.name == 'AGENTS.md' and not guide)
                or rel.startswith('.github/tests/repository_intelligence/')
                or rel.startswith('.github/scripts/') and 'repository_intelligence' in p.name
                or rel.startswith('assets/repository-intelligence/') and not ri)


ledger = json.loads((ROOT / 'runs.json').read_text())
assert len(ledger['runs']) == 12
freeze = json.loads((ROOT / 'freeze.json').read_text())
manifest = json.loads((ROOT / 'source-manifest.json').read_text())
for name, digest in manifest.items():
    assert sha((ROOT / 'source' / name).read_bytes()) == digest, name
with zipfile.ZipFile(STUDY / 'frozen-inputs.zip') as z:
    for name, digest in freeze['input_sha256'].items():
        assert sha(z.read(name)) == digest == sha((ROOT / name).read_bytes()), name
observations = []
for row in ledger['runs']:
    rid = row['run_id']
    assert row['status'] == 'answer_received' and row['publication_commit'] and row['remote_tree_verified']
    guide, ri = row['arm'] in {'AGENTS', 'AGENTS_RI'}, row['arm'] in {'RI', 'AGENTS_RI'}
    raw = (ROOT / 'runs' / (rid + '-answer.txt')).read_bytes()
    assert sha(raw) == row['first_answer_sha256']
    assert raw == (STUDY / 'answers' / (rid + '.txt')).read_bytes()
    with zipfile.ZipFile(STUDY / 'evidence' / (rid + '.zip')) as z:
        assert raw == z.read(rid + '-answer.txt')
        journal = z.read(rid + '-journal.jsonl')
        assert journal == (ROOT / 'runs' / (rid + '-journal.jsonl')).read_bytes()
    entries = [json.loads(s) for s in journal.decode().splitlines()]
    assert len(entries) == row['driver_operations'] <= 90
    assert row['driver_operations'] == row['start_delivery_operations'] + row['source_ri_operations']
    assert row['measured_input_utf8_bytes'] == row['native_bootstrap_utf8_bytes'] + sum(e['response_utf8_bytes'] for e in entries)
    for e in entries:
        response = e['response']
        assert e['response_utf8_bytes'] == len((json.dumps(response, ensure_ascii=False) + '\n').encode())
        if 'error' in response:
            continue
        paths = []
        if response.get('kind') == 'source':
            paths = [response['path']]
            source = (ROOT / 'source' / paths[0]).read_bytes()
            assert sha(source) == response['content_sha256']
            offset = response['offset']
            assert source.decode()[offset:offset + len(response['text'])] == response['text']
        elif e['operation'] == 'list':
            paths = response['paths']
        elif e['operation'] == 'search':
            paths = [m['path'] for m in response['matches']]
        for path in paths:
            assert path in manifest and allowed(path, guide, ri), (rid, path)
    assert not row['reader_boundary_findings']
    assert all(row['read_coverage'].values())
    observations.append({'run_id': rid, 'all_returned_source_and_ri_pages_complete': True,
                         'cited_paths_without_direct_full_read': row.get('cited_existing_files_without_complete_read', []),
                         'reader_errors': row['reader_errors'],
                         'access_deviations_section': raw.decode().split('Access deviations', 1)[-1].strip()})
old = []
for dirname in ['2026-09-17-initial', '2026-09-18-inventory-pilot']:
    rel = '.github/tests/repository_intelligence/studies/' + dirname
    subprocess.run(['git', 'diff', '--exit-code', 'be9f098acee1f7edaa6c8952ea7867f275902c8b', 'HEAD', '--', rel], cwd=REPO, check=True, capture_output=True)
    old.append(dirname)
result = {'source_files_verified': len(manifest), 'frozen_inputs_verified': len(freeze['input_sha256']),
          'completed_persisted_slots': 12, 'older_studies_unchanged': old,
          'observations': observations,
          'limit': 'This audits retained reader traffic and bytes, not all platform tools, hidden context, backend identity or cognition. Mentioning a file as a change target, excluded source or interpretation-path member is not automatically a missing critical-source read; review those mentions substantively.'}
(ROOT / 'audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'observations'}, ensure_ascii=False))
