"""Freeze the first assessor output before any score-to-condition join."""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent / 'ua-repo/.github/tests/repository_intelligence/studies/2026-09-21-work-factorial'
raw = (ROOT / 'assessment/scores.json').read_bytes()
freeze = {'assessment_sha256': hashlib.sha256(raw).hexdigest(),
          'frozen_observed_at': datetime.now(timezone.utc).isoformat(),
          'native_assessor': '/root/work_factorial_assessor',
          'mapping_join_performed': False,
          'assessment_input_freeze': json.loads((ROOT / 'assessment-input-freeze.json').read_text())}
with (ROOT / 'assessment-first-freeze.json').open('x') as out:
    out.write(json.dumps(freeze, ensure_ascii=False, indent=2) + '\n')
with (ROOT / 'scores-first.json').open('xb') as out:
    out.write(raw)
with zipfile.ZipFile(STUDY / 'assessment-first.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    z.writestr('scores-first.json', raw)
    z.write(ROOT / 'assessment-first-freeze.json', 'assessment-first-freeze.json')
    z.write(ROOT / 'freeze_assessment.py', 'organizer/freeze_assessment.py')
scores = json.loads(raw)
packet = json.loads((ROOT / 'assessment/packet.json').read_text())
expected = {a['answer_id']: a['task_id'] for a in packet['answers']}
assert len(scores['assessments']) == 12
assert {a['answer_id']: a['task_id'] for a in scores['assessments']} == expected
assert scores['source_commit'] == packet['source_commit']
for answer in scores['assessments']:
    assert len(answer['criteria']) == 5
    assert {c['criterion_index'] for c in answer['criteria']} == {1, 2, 3, 4, 5}
    assert all(c['verdict'] in {'met', 'not_met'} for c in answer['criteria'])
    assert len(answer['serious_errors']) == 3
    assert {e['error_index'] for e in answer['serious_errors']} == {1, 2, 3}
    assert answer['score'] in {0, 1, 2}
    severe = any(e['present'] for e in answer['serious_errors']) or bool(answer['additional_material_errors'])
    unmet = any(c['verdict'] == 'not_met' for c in answer['criteria'])
    assert answer['score'] == (0 if severe else 1 if unmet else 2)
print(json.dumps(freeze, ensure_ascii=False))
